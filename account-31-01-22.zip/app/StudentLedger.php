<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentLedger extends Model
{
    protected $table="student_ledger";
}
