<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentsLedger extends Model
{
    //
}
